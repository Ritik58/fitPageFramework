# fitPageFramework
India Running is a Race registration platform powered by the Organizer dashboard.
