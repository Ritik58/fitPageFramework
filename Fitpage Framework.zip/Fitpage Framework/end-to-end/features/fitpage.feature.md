### Feature: Event Creation

`@firstScenario``login` 
### Scenario Outline: Organiser Login
    - Given organiser open the india running
    - When organiser login to india running with "<email>"
    - And organiser completes event information page with "<EventName>","<EventType>","<location>","<address>","<area>","<city>","<state>","<pincode>","<country>","<>","<startDate>","<endDate>"
    - And organiser completes event details page with "<race>" 
    - Then event should be listed on india running website

 ### Examples:
    |   index   |   email                   | EventName     | EventType     | location  |address    |   area   |  city  |   state   |   pincode |   country |startDate  |endDate|race|
    |   1       |   fitpagetest@gmail.com   | TestEvents    | On Ground     |   Pune    |ABCD       |   Hinje  |  Pune  |   Maha    |   411057  |   India   |22-05-2025 |25-05-2025|400mtr race|


<!-- `@secondScenario``createEvent`
### Scenario Outline: create Event
    - Given organiser open the india running
    - When organiser login to india running with "<email>"
    - And organiser completes event information page with "<EventName>","<EventType>","<location>","<address>","<area>","<city>","<state>","<pincode>","<country>","<>","<startDate>","<endDate>"
    - And organiser completes event details page with "<race>" 
    - Then event should be listed on india running website

 ### Examples:
    |   index   |   email                   | EventName     | EventType     | location  |address    |   area   |  city  |   state   |   pincode |   country |startDate  |endDate|race|
    |   1       |   fitpagetest@gmail.com   | TestEvents    | On Ground     |   Pune    |ABCD       |   Hinje  |  Pune  |   Maha    |   411057  |   India   |22-05-2025 |25-05-2025|400mtr race| -->