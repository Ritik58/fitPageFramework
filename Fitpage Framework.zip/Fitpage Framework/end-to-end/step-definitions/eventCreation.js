const { Given, When, Then} = require('@cucumber/cucumber');

Given('organiser open the india running', async function() {
  await loginPage.openUrl()});

When('organiser login to india running with {string}', async function(email) {
    await loginPage.login(email)
});

When('organiser signup to india running with {string},{string},{string} and {string}',async function(firstName,lastName,mobileNumber,organisationName) {
    
    await signUp.login(firstName,lastName,mobileNumber,organisationName);

});

When('organiser completes event information page with {string},{string},{string},{string},{string},{string},{string},{string},{string}', async function(EventName,EventType,location,address,area,city,state,pincode,country) {
    await createEvent.eventInformation(EventName,EventType,location,address,area,city,state,pincode,country);
  });

  When('organiser completes event details page with {string}', async function(race) {
    await createEvent.eventDetails(race);
  });

   

