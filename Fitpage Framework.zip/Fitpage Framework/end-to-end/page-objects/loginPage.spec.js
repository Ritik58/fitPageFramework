const { expect } = require('@playwright/test');
const { log } = require('console');

/* eslint-disable */
class loginPage{
  constructor(page) {
    super();
    this.page = page;
    this.pageUrl = "https://indiarunning-organizer-dashboard-staging.bombayrunning.com/";
    this.loginPage = "https://indiarunning-organizer-dashboard-staging.bombayrunning.com/login";
    this.email = "(//h2[text()='Sign In/Sign Up'])[1]//following::input[1]";
    this.getOtp = "(//button[contains(text(),'Get OTP')])[1]";
    this.otp1 = "//p[contains(text(),'OTP has been sent on abcd@gmail.com')]//following::input[1]";
    this.otp2 = "//p[contains(text(),'OTP has been sent on abcd@gmail.com')]//following::input[2]";
    this.otp3 = "//p[contains(text(),'OTP has been sent on abcd@gmail.com')]//following::input[3]";
    this.otp4 = "//p[contains(text(),'OTP has been sent on abcd@gmail.com')]//following::input[4]";
    this.firstName = "//*[contains(text(),'First Name')]//following::input[1]";
    this.lastName = "//*[contains(text(),'Last Name')]//following::input[1]";
    this.mobileNumber = '//*[contains(text(),"Mobile Number")]//following::input[1]';
    this.organisationName = '//*[contains(text(),"Organization Name")]//following::input[1]';

}

  async openUrl() {
    await this.page.goto(pageUrl);
    await page.waitForTimeout(process.env.BASH_TIMEOUT * 100);
    await page.waitForLoadState();
    await expect(await this.page).toHaveURL(loginPage, { timeout: 15000 });
  }

  async login() {
    await this.email.fill(email);
    await this.getOtp.click();
    await page.fill(this.otp1, '1');
    await page.fill(this.otp2, '2');
    await page.fill(this.otp3, '3');
    await page.fill(this.otp4, '4');
    await page.click('button:has-text("Verify OTP")');
 
  }

 async signUp(){
    await this.firstName.fill(firstName);
    await this.lastName.fill(lastName);
    await this.mobileNumber.fill(mobileNumber);
    await this.organisationName.fill(organisationName);
    await page.click('button:has-text("Continue")');
    await page.fill(this.otp1, '1');
    await page.fill(this.otp2, '2');
    await page.fill(this.otp3, '3');
    await page.fill(this.otp4, '4');
    await page.click('button:has-text("Verify OTP")');

 }
}

module.exports = { loginPage };
