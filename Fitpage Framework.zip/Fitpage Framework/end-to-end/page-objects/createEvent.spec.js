const { expect } = require('@playwright/test');

/* eslint-disable */
class createEvent{
  constructor(page) {
    super();
    this.page = page;
    this.createEvent    = "//div[contains(text(),'+ Create Event')]";
    this.eventName      = '//*[contains(text(),"Event Name")]//following::input[1]';
    this.ongroundEvent  = '//*[contains(text(),"Event Type")]//following::span[text()="On-Ground"]';
    this.virtualEvent   = '//*[contains(text(),"Event Type")]//following::span[text()="Virtual"]';
    this.bothEvent      = '//*[contains(text(),"Event Type")]//following::span[text()="On-Ground+Virtual"]';
    this.startDate      = '//*[contains(text(),"Start Date")]//following::input[1]' ;
    this.endDate        = '//*[contains(text(),"End Date")]//following::input[1]';
    this.location       = '//*[contains(text(),"Location")]//following::input[1]';
    this.address        = '//*[contains(text(),"Address")]//following::input[1]';
    this.area           = '//*[contains(text(),"Area")]//following::input[1]';
    this.city           = '//*[contains(text(),"City")]//following::input[1]';
    this.state          = '//*[contains(text(),"State")]//following::input[1]';
    this.pincode        = '//*[contains(text(),"PinCode")]//following::input[1]';
    this.Country        = '//*[contains(text(),"Country")]//following::select[1]';
    this.Race           = '//*[contains(text(),"About Race")]//following::div[6]';

}

  async eventInformation() {

    await this.createEvent.click();
    await this.eventName.fill(EventName);
    if(EventName == "On Ground"){
        await this.ongroundEvent.click();
        await this.location.fill(location);
        await this.address.fill(address);
        await this.area.fill(area);
        await this.city.fill(city);
        await this.state.fill(state);
        await this.pincode.fill(pincode);
        await this.Country.select(country);
    }    
    else if(EventName == "Virtual Event"){
        await this.virtualEvent.click();
    }
    else{
    
        await this.bothEvent.click();
        await this.location.fill(location);
        await this.address.fill(address);
        await this.area.fill(area);
        await this.city.fill(city);
        await this.state.fill(state);
        await this.pincode.fill(pincode);
        await this.Country.select(country);

    }
    await this.startDate.fill(startDate);
    await this.endDate.fill(endDate);
    await this.page.locator('//*[contains(text(),"Save and Proceed")]');


  }

  async eventDetails() {

    await this.race.fill(email);
    const webBannerPath = './FitPage Framework/end-to-end/testImage.png'; 
    await page.setInputFiles('input[type="file"][name="webBanner"]', webBannerPath);

    // Upload Mobile Banner
    const mobileBannerPath = './FitPage Framework/end-to-end/testImage.png';
    await page.setInputFiles('input[type="file"][name="mobileBanner"]', mobileBannerPath);

    const galleryImage = './FitPage Framework/end-to-end/testImage.png';
    await page.setInputFiles('input[type="file"][name="galleryImage"]', galleryImage);

    this.page.locator('//*[contains(text(),"Conditions")]//following::input[1]').fill(termsCondition);
    this.page.locator('//*[contains(text(),"FAQ")]//following::input[1]').fill(FAQ);

    this.page.locator('//*[contains(text(),"Save and Proceed")]').click();
 
  }

 async signUp(firstName,lastName,mobileNumber,organisationName){
    await this.firstName.fill(firstName);
    await this.lastName.fill(lastName);
    await this.mobileNumber.fill(mobileNumber);
    await this.organisationName.fill(organisationName);
    await page.click('button:has-text("Continue")');
    await page.fill(this.otp1, '1');
    await page.fill(this.otp2, '2');
    await page.fill(this.otp3, '3');
    await page.fill(this.otp4, '4');
    await page.click('button:has-text("Verify OTP")');

 }
}

module.exports = { createEvent };
