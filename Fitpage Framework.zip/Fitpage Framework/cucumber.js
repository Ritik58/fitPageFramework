// const common = {

//   formatOptions: { snippetInterface: '<interface>' },
//   publishQuiet: true,
//   paths: ['end-to-end/features', 'end-to-end/features/**/*.feature.md'],
//   require: ['end-to-end/step-definitions/**/*.js'],
//   format: [
//     'html:end-to-end/test-evidences/scenario-report/e2e-test-result.html',
//     'json:end-to-end/test-evidences/scenario-report/e2e-test-result.json',
//     'message:end-to-end/test-evidences/scenario-report/e2e-test-result.ndjson',
//     'junit:end-to-end/test-evidences/scenario-report/e2e-test-result.xml',
//   ],
// };

module.exports = {
    default: `--format-options '{"snippetInterface": "async-await"}' --require ./step-definitions/**/*.js --require ./support/**/*.js --publish-quiet`,
    
};